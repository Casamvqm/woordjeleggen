import React, { useCallback, useMemo } from 'react';
import toast, { Toaster } from 'react-hot-toast';
import Board from './components/Board.jsx';
import Rack from './components/Rack.jsx';
import ScoreBoard from './components/ScoreBoard.jsx';
import GameControls from './components/GameControls.jsx';
import SetupScreen from './components/SetupScreen.jsx';
import EndScreen from './components/EndScreen.jsx';
import BlankTileModal from './components/BlankTileModal.jsx';
import { useGameState } from './hooks/useGameState.js';
import { useDictionary } from './hooks/useDictionary.js';
import { getValidPositions } from './utils/wordValidator.js';
import styles from './App.module.css';

export default function App() {
  const { dictionary, loading: dictLoading, wordCount } = useDictionary();

  const game = useGameState(dictionary);

  const {
    board, bag, players, currentPlayer, placedTiles,
    selectedRackTile, gameStatus, lastMoveInfo, moveHistory,
    blankAssignment, isFirstMove,
    startGame, selectRackTile, placeTileOnBoard, assignBlankAndPlace,
    returnTileToRack, returnAllTiles, confirmMove, skipTurn, exchangeTiles,
    setBlankAssignment,
  } = game;

  const currentPlayerData = players[currentPlayer];

  // Compute valid positions for UI hints
  const validPositions = useMemo(() => {
    if (gameStatus !== 'playing' || !selectedRackTile) return new Set();
    return getValidPositions(placedTiles, board, isFirstMove);
  }, [selectedRackTile, placedTiles, board, isFirstMove, gameStatus]);

  const handleCellClick = useCallback((row, col) => {
    if (gameStatus !== 'playing') return;
    if (!selectedRackTile) {
      // Maybe clicking to return a placed tile
      return;
    }
    const result = placeTileOnBoard(row, col);
    if (!result.success) {
      toast.error(result.error, { duration: 2000 });
    }
  }, [gameStatus, selectedRackTile, placeTileOnBoard]);

  const handleConfirm = useCallback(() => {
    const result = confirmMove();
    if (!result.success) {
      toast.error(result.error, { duration: 3000 });
    } else {
      const words = result.words.map(w => w.word).join(', ');
      if (result.bingo) {
        toast.success(`🎉 BINGO! ${words} — +${result.score} punten!`, {
          duration: 4000,
          style: { background: '#1a1208', color: '#ffd700', border: '2px solid #ffd700' }
        });
      } else {
        toast.success(`${words} — +${result.score} punt${result.score !== 1 ? 'en' : ''}`, {
          duration: 2500,
          style: { background: '#1a2e1a', color: '#a8e6a8', border: '1px solid #1a9b7b' }
        });
      }
    }
  }, [confirmMove]);

  const handleSkip = useCallback(() => {
    skipTurn();
    toast(`${currentPlayerData?.name} past.`, {
      duration: 2000,
      icon: '⏭️',
      style: { background: '#1a1a2e', color: 'rgba(255,255,255,0.8)' }
    });
  }, [skipTurn, currentPlayerData]);

  const handleExchange = useCallback((tileIds) => {
    const result = exchangeTiles(tileIds);
    if (!result.success) {
      toast.error(result.error, { duration: 2500 });
    } else {
      toast(`${tileIds.length} letter${tileIds.length !== 1 ? 's' : ''} geruild.`, {
        duration: 2000,
        icon: '🔄',
        style: { background: '#1a1a2e', color: 'rgba(255,255,255,0.8)' }
      });
    }
  }, [exchangeTiles]);

  const handleAssignBlank = useCallback((letter) => {
    assignBlankAndPlace(letter);
  }, [assignBlankAndPlace]);

  const handleCancelBlank = useCallback(() => {
    setBlankAssignment(null);
  }, [setBlankAssignment]);

  if (gameStatus === 'setup') {
    return (
      <div className={styles.appBg}>
        <SetupScreen onStart={startGame} />
      </div>
    );
  }

  return (
    <div className={styles.appBg}>
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            fontFamily: 'Outfit, sans-serif',
            fontSize: '14px',
            fontWeight: 500,
          }
        }}
      />

      {blankAssignment && (
        <BlankTileModal
          onAssign={handleAssignBlank}
          onCancel={handleCancelBlank}
        />
      )}

      {gameStatus === 'ended' && (
        <EndScreen
          players={players}
          onNewGame={() => startGame(players.map(p => p.name))}
        />
      )}

      <div className={styles.layout}>
        {/* Left sidebar */}
        <aside className={styles.sidebar}>
          <div className={styles.logoSmall}>W</div>
          <ScoreBoard
            players={players}
            currentPlayer={currentPlayer}
            bagCount={bag.length}
            moveHistory={moveHistory}
            gameStatus={gameStatus}
          />
          <GameControls
            onConfirm={handleConfirm}
            onSkip={handleSkip}
            onExchange={handleExchange}
            onReturnAll={returnAllTiles}
            placedCount={placedTiles.length}
            rackTiles={currentPlayerData?.rack || []}
            canExchange={bag.length >= 7}
            disabled={gameStatus !== 'playing'}
            gameStatus={gameStatus}
            currentPlayerName={currentPlayerData?.name}
          />
          {dictLoading ? (
            <div className={styles.dictStatus}>Woordenlijst laden…</div>
          ) : (
            <div className={styles.dictStatus}>{wordCount.toLocaleString('nl')} woorden geladen</div>
          )}
        </aside>

        {/* Board + rack */}
        <main className={styles.main}>
          <Board
            board={board}
            placedTiles={placedTiles}
            selectedRackTile={selectedRackTile}
            validPositions={validPositions}
            onCellClick={handleCellClick}
            onTileReturn={returnTileToRack}
          />

          <div className={styles.rackArea}>
            <div className={styles.rackLabel}>
              {currentPlayerData?.name}'s letters
            </div>
            <Rack
              tiles={currentPlayerData?.rack || []}
              selectedTile={selectedRackTile}
              onTileSelect={selectRackTile}
              disabled={gameStatus !== 'playing'}
            />
            {placedTiles.length > 0 && (
              <div className={styles.placedHint}>
                Klik een geplaatste letter om terug te nemen
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
