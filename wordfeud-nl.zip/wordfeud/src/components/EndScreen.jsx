import React from 'react';
import styles from './EndScreen.module.css';

const EndScreen = ({ players, onNewGame }) => {
  const sorted = [...players].sort((a, b) => b.score - a.score);
  const winner = sorted[0];
  const isDraw = sorted[0].score === sorted[1].score;

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <div className={styles.trophy}>🏆</div>
        <h2 className={styles.title}>
          {isDraw ? 'Gelijkspel!' : `${winner.name} wint!`}
        </h2>
        <p className={styles.subtitle}>Eindstand</p>

        <div className={styles.scores}>
          {sorted.map((player, i) => (
            <div key={player.id} className={`${styles.scoreRow} ${i === 0 && !isDraw ? styles.winner : ''}`}>
              <span className={styles.rank}>{i + 1}</span>
              <span className={styles.playerName}>{player.name}</span>
              <span className={styles.playerScore}>{player.score} pt</span>
            </div>
          ))}
        </div>

        <button className={styles.newGameBtn} onClick={onNewGame}>
          Nieuw spel
        </button>
      </div>
    </div>
  );
};

export default EndScreen;
