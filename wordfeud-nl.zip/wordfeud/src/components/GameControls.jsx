import React, { useState } from 'react';
import styles from './GameControls.module.css';

const GameControls = ({
  onConfirm,
  onSkip,
  onExchange,
  onReturnAll,
  placedCount,
  rackTiles,
  canExchange,
  disabled,
  gameStatus,
  currentPlayerName,
}) => {
  const [exchangeMode, setExchangeMode] = useState(false);
  const [exchangeSelected, setExchangeSelected] = useState(new Set());

  const toggleExchangeTile = (id) => {
    setExchangeSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleExchangeConfirm = () => {
    if (exchangeSelected.size === 0) return;
    onExchange([...exchangeSelected]);
    setExchangeMode(false);
    setExchangeSelected(new Set());
  };

  const handleExchangeCancel = () => {
    setExchangeMode(false);
    setExchangeSelected(new Set());
  };

  if (gameStatus === 'ended') {
    return (
      <div className={styles.controls}>
        <div className={styles.gameOverMsg}>Spel voorbij!</div>
      </div>
    );
  }

  if (exchangeMode) {
    return (
      <div className={styles.controls}>
        <div className={styles.exchangeInfo}>
          Klik letters in je rek om te ruilen ({exchangeSelected.size} geselecteerd)
        </div>
        <div className={styles.exchangeRack}>
          {rackTiles.map(tile => (
            <div
              key={tile.id}
              className={`${styles.exchangeTile} ${exchangeSelected.has(tile.id) ? styles.exchangeChosen : ''}`}
              onClick={() => toggleExchangeTile(tile.id)}
            >
              <span className={styles.exchangeLetter}>{tile.displayLetter || tile.letter}</span>
              <span className={styles.exchangePoints}>{tile.points}</span>
            </div>
          ))}
        </div>
        <div className={styles.buttonRow}>
          <button
            className={`${styles.btn} ${styles.btnPrimary}`}
            onClick={handleExchangeConfirm}
            disabled={exchangeSelected.size === 0}
          >
            Ruil {exchangeSelected.size > 0 ? `(${exchangeSelected.size})` : ''}
          </button>
          <button className={`${styles.btn} ${styles.btnSecondary}`} onClick={handleExchangeCancel}>
            Annuleer
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.controls}>
      <div className={styles.turnInfo}>
        <span className={styles.turnDot} />
        Beurt: <strong>{currentPlayerName}</strong>
        {placedCount > 0 && <span className={styles.placedInfo}> — {placedCount} letter{placedCount !== 1 ? 's' : ''} geplaatst</span>}
      </div>

      <div className={styles.buttonRow}>
        <button
          className={`${styles.btn} ${styles.btnConfirm}`}
          onClick={onConfirm}
          disabled={disabled || placedCount === 0}
        >
          ✓ Speel woord
        </button>
        {placedCount > 0 && (
          <button
            className={`${styles.btn} ${styles.btnSecondary}`}
            onClick={onReturnAll}
            disabled={disabled}
          >
            ↩ Terug
          </button>
        )}
      </div>

      <div className={styles.buttonRow}>
        <button
          className={`${styles.btn} ${styles.btnSkip}`}
          onClick={onSkip}
          disabled={disabled || placedCount > 0}
        >
          Passen
        </button>
        <button
          className={`${styles.btn} ${styles.btnExchange}`}
          onClick={() => setExchangeMode(true)}
          disabled={disabled || !canExchange || placedCount > 0}
          title={!canExchange ? 'Niet genoeg letters in de zak' : 'Letters ruilen'}
        >
          ⇄ Ruilen
        </button>
      </div>
    </div>
  );
};

export default GameControls;
