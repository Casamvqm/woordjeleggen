import React, { useState } from 'react';
import styles from './BlankTileModal.module.css';

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

const BlankTileModal = ({ onAssign, onCancel }) => {
  const [selected, setSelected] = useState(null);

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <h2 className={styles.title}>Joker — Kies een letter</h2>
        <p className={styles.subtitle}>Welke letter moet deze joker voorstellen?</p>
        <div className={styles.grid}>
          {ALPHABET.map(letter => (
            <button
              key={letter}
              className={`${styles.letterBtn} ${selected === letter ? styles.selectedBtn : ''}`}
              onClick={() => setSelected(letter)}
            >
              {letter}
            </button>
          ))}
        </div>
        <div className={styles.actions}>
          <button
            className={styles.confirmBtn}
            disabled={!selected}
            onClick={() => selected && onAssign(selected)}
          >
            Bevestig
          </button>
          <button className={styles.cancelBtn} onClick={onCancel}>
            Annuleer
          </button>
        </div>
      </div>
    </div>
  );
};

export default BlankTileModal;
