import React, { useState } from 'react';
import styles from './SetupScreen.module.css';

const SetupScreen = ({ onStart }) => {
  const [names, setNames] = useState(['Speler 1', 'Speler 2']);

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmed = names.map(n => n.trim() || 'Speler');
    onStart(trimmed);
  };

  return (
    <div className={styles.setup}>
      <div className={styles.hero}>
        <div className={styles.logoTile}>W</div>
        <h1 className={styles.title}>Wordfeud</h1>
        <p className={styles.tagline}>Het klassieke woordspel — nu in het Nederlands</p>
      </div>

      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.players}>
          {names.map((name, i) => (
            <div key={i} className={styles.playerField}>
              <label className={styles.label}>Speler {i + 1}</label>
              <input
                className={styles.input}
                type="text"
                value={name}
                onChange={e => {
                  const next = [...names];
                  next[i] = e.target.value;
                  setNames(next);
                }}
                placeholder={`Speler ${i + 1}`}
                maxLength={20}
              />
            </div>
          ))}
        </div>

        <button type="submit" className={styles.startBtn}>
          Spel starten →
        </button>
      </form>

      <div className={styles.legend}>
        <div className={styles.legendTitle}>Bonusvakjes</div>
        <div className={styles.legendGrid}>
          <div className={styles.legendItem}>
            <div className={styles.legendSwatch} style={{ background: '#c23b22' }} />
            <span>3× woord</span>
          </div>
          <div className={styles.legendItem}>
            <div className={styles.legendSwatch} style={{ background: '#e8956d' }} />
            <span>2× woord</span>
          </div>
          <div className={styles.legendItem}>
            <div className={styles.legendSwatch} style={{ background: '#1a6fa8' }} />
            <span>3× letter</span>
          </div>
          <div className={styles.legendItem}>
            <div className={styles.legendSwatch} style={{ background: '#5bb8d4' }} />
            <span>2× letter</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SetupScreen;
