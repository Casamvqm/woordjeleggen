import React from 'react';
import Tile from './Tile.jsx';
import styles from './Rack.module.css';

const Rack = ({
  tiles,
  selectedTile,
  onTileSelect,
  exchangeMode,
  exchangeSelected,
  onExchangeToggle,
  disabled,
}) => {
  const slots = Array.from({ length: 7 }, (_, i) => tiles[i] || null);

  return (
    <div className={`${styles.rackContainer} ${disabled ? styles.disabled : ''}`}>
      <div className={styles.rack}>
        {slots.map((tile, i) => (
          <div
            key={tile?.id || `empty-${i}`}
            className={`${styles.slot} ${!tile ? styles.emptySlot : ''} ${exchangeMode && tile && exchangeSelected?.has(tile.id) ? styles.exchangeSelected : ''}`}
            onClick={() => {
              if (!tile || disabled) return;
              if (exchangeMode) {
                onExchangeToggle?.(tile.id);
              } else {
                onTileSelect(tile);
              }
            }}
          >
            {tile && (
              <Tile
                tile={tile}
                selected={!exchangeMode && selectedTile?.id === tile.id}
                size="normal"
                draggable={!disabled && !exchangeMode}
                onDragStart={(e) => {
                  e.dataTransfer.setData('text/plain', tile.id);
                  onTileSelect(tile);
                }}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Rack;
