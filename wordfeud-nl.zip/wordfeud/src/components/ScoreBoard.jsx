import React from 'react';
import styles from './ScoreBoard.module.css';

const ScoreBoard = ({ players, currentPlayer, bagCount, moveHistory, gameStatus }) => {
  const recentMoves = [...moveHistory].reverse().slice(0, 5);

  return (
    <div className={styles.scoreboard}>
      <div className={styles.players}>
        {players.map((player, i) => {
          const isWinner = gameStatus === 'ended' &&
            player.score === Math.max(...players.map(p => p.score));
          return (
            <div
              key={player.id}
              className={`${styles.playerCard} ${i === currentPlayer && gameStatus === 'playing' ? styles.active : ''} ${isWinner ? styles.winner : ''}`}
            >
              <div className={styles.playerName}>
                {i === currentPlayer && gameStatus === 'playing' && (
                  <span className={styles.turnIndicator}>▶</span>
                )}
                {isWinner && <span className={styles.winnerIcon}>🏆</span>}
                <span className={styles.nameText}>{player.name}</span>
              </div>
              <div className={styles.playerScore}>{player.score}</div>
              <div className={styles.rackCount}>
                {player.rack.length} letter{player.rack.length !== 1 ? 's' : ''}
              </div>
            </div>
          );
        })}
      </div>

      <div className={styles.bagInfo}>
        <span className={styles.bagIcon}>🎲</span>
        <span className={styles.bagLabel}>Zak:</span>
        <span className={styles.bagCount}>{bagCount}</span>
        <span className={styles.bagLabel}> letter{bagCount !== 1 ? 's' : ''}</span>
      </div>

      {recentMoves.length > 0 && (
        <div className={styles.history}>
          <div className={styles.historyTitle}>Laatste zetten</div>
          {recentMoves.map((move, i) => (
            <div key={i} className={styles.historyEntry}>
              <span className={styles.historyPlayer}>{players[move.player]?.name}:</span>
              {move.skip && <span className={styles.historyAction}> Gepast</span>}
              {move.exchange && <span className={styles.historyAction}> Geruild</span>}
              {move.words && (
                <span className={styles.historyWords}>
                  {' '}{move.words.map(w => w.word).join(', ')}
                  <span className={styles.historyScore}> +{move.score}</span>
                  {move.bingo && <span className={styles.bingo}> BINGO!</span>}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ScoreBoard;
