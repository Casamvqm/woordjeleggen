import React from 'react';
import styles from './Tile.module.css';

const Tile = ({
  tile,
  selected,
  onClick,
  onDragStart,
  onDragEnd,
  draggable = true,
  size = 'normal',
  placed = false,
  animate = false,
}) => {
  if (!tile) return null;

  const letter = tile.displayLetter || tile.letter;
  const isBlank = tile.isBlank || tile.letter === '*';

  return (
    <div
      className={`${styles.tile} ${styles[size]} ${selected ? styles.selected : ''} ${placed ? styles.placed : ''} ${animate ? styles.animate : ''} ${isBlank ? styles.blank : ''}`}
      onClick={onClick}
      draggable={draggable}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      title={`${letter} (${tile.points} punt${tile.points !== 1 ? 'en' : ''})`}
    >
      <span className={styles.letter}>{letter}</span>
      <span className={styles.points}>{tile.points}</span>
    </div>
  );
};

export default Tile;
