import React, { useCallback, useRef, useState } from 'react';
import { BOARD_SIZE, PREMIUM_TYPES, PREMIUM_COLORS, PREMIUM_LABELS, getPremiumType } from '../utils/boardConfig.js';
import Tile from './Tile.jsx';
import styles from './Board.module.css';

const { NORMAL, START } = PREMIUM_TYPES;

const BoardCell = React.memo(({
  row, col, premiumType, boardTile, placedTile, isValid, isSelected,
  onClick, onDragOver, onDrop, animateNew,
}) => {
  const tile = placedTile || boardTile;
  const label = PREMIUM_LABELS[premiumType];
  const bgColor = PREMIUM_COLORS[premiumType] || PREMIUM_COLORS[NORMAL];

  return (
    <div
      className={`${styles.cell} ${isValid && !tile ? styles.validTarget : ''}`}
      style={{ backgroundColor: tile ? undefined : bgColor }}
      onClick={onClick}
      onDragOver={onDragOver}
      onDrop={onDrop}
      data-row={row}
      data-col={col}
    >
      {tile ? (
        <Tile
          tile={tile}
          placed={!!boardTile}
          animate={!!placedTile && animateNew}
          size="normal"
        />
      ) : label ? (
        <span className={styles.premiumLabel}>{label}</span>
      ) : null}
    </div>
  );
});

const Board = ({
  board,
  placedTiles,
  selectedRackTile,
  validPositions,
  onCellClick,
  onTileReturn,
}) => {
  const [newlyPlaced, setNewlyPlaced] = useState(new Set());
  const [dragTile, setDragTile] = useState(null);

  const handleCellClick = useCallback((row, col) => {
    // If clicking on a placed (unconfirmed) tile, return it to rack
    const placed = placedTiles.find(t => t.row === row && t.col === col);
    if (placed) {
      onTileReturn(placed.id);
      return;
    }
    onCellClick(row, col);
    // Track for animation
    setNewlyPlaced(prev => {
      const next = new Set(prev);
      next.add(`${row},${col}`);
      setTimeout(() => {
        setNewlyPlaced(p => {
          const n = new Set(p);
          n.delete(`${row},${col}`);
          return n;
        });
      }, 400);
      return next;
    });
  }, [placedTiles, onCellClick, onTileReturn]);

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }, []);

  const handleDrop = useCallback((e, row, col) => {
    e.preventDefault();
    onCellClick(row, col);
  }, [onCellClick]);

  const placedSet = new Map(placedTiles.map(t => [`${t.row},${t.col}`, t]));

  return (
    <div className={styles.boardWrapper}>
      <div className={styles.board}>
        {Array.from({ length: BOARD_SIZE }, (_, row) =>
          Array.from({ length: BOARD_SIZE }, (_, col) => {
            const premiumType = getPremiumType(row, col);
            const boardTile = board[row][col];
            const placedTile = placedSet.get(`${row},${col}`);
            const posKey = `${row},${col}`;
            const isValid = validPositions?.has(posKey);
            const isAnimated = newlyPlaced.has(posKey);

            return (
              <BoardCell
                key={posKey}
                row={row}
                col={col}
                premiumType={premiumType}
                boardTile={boardTile}
                placedTile={placedTile}
                isValid={isValid}
                onClick={() => handleCellClick(row, col)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, row, col)}
                animateNew={isAnimated}
              />
            );
          })
        )}
      </div>
    </div>
  );
};

export default Board;
