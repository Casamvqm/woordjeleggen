import { useState, useCallback, useRef } from 'react';
import { createBag, shuffleBag } from '../utils/tileDistribution.js';
import { BOARD_SIZE } from '../utils/boardConfig.js';
import { calculateMoveScore } from '../utils/scoring.js';
import { validatePlacement, validateWords } from '../utils/wordValidator.js';

const RACK_SIZE = 7;

const createEmptyBoard = () =>
  Array.from({ length: BOARD_SIZE }, () => Array(BOARD_SIZE).fill(null));

const drawTiles = (rack, bag, count) => {
  const newBag = [...bag];
  const newRack = [...rack];
  const drawn = [];
  for (let i = 0; i < count && newBag.length > 0; i++) {
    drawn.push(newBag.pop());
  }
  return { newRack: [...newRack, ...drawn], newBag, drawn };
};

const fillRack = (rack, bag) => {
  const needed = RACK_SIZE - rack.length;
  return drawTiles(rack, bag, needed);
};

export const useGameState = (dictionary) => {
  const [board, setBoard] = useState(createEmptyBoard);
  const [bag, setBag] = useState(() => createBag());
  const [players, setPlayers] = useState([
    { id: 0, name: 'Speler 1', score: 0, rack: [] },
    { id: 1, name: 'Speler 2', score: 0, rack: [] },
  ]);
  const [currentPlayer, setCurrentPlayer] = useState(0);
  const [placedTiles, setPlacedTiles] = useState([]); // tiles being placed this turn
  const [selectedRackTile, setSelectedRackTile] = useState(null);
  const [gameStatus, setGameStatus] = useState('setup'); // setup | playing | ended
  const [consecutiveSkips, setConsecutiveSkips] = useState(0);
  const [lastMoveInfo, setLastMoveInfo] = useState(null);
  const [moveHistory, setMoveHistory] = useState([]);
  const [blankAssignment, setBlankAssignment] = useState(null); // {tileId, letter} pending

  const isFirstMove = board.every(row => row.every(cell => cell === null)) && placedTiles.length === 0
    && moveHistory.length === 0;

  // Start game — deal tiles
  const startGame = useCallback((playerNames) => {
    const freshBag = createBag();
    let currentBag = [...freshBag];

    const newPlayers = playerNames.map((name, id) => {
      const rack = [];
      const { newRack, newBag } = fillRack(rack, currentBag);
      currentBag = newBag;
      return { id, name, score: 0, rack: newRack };
    });

    setPlayers(newPlayers);
    setBag(currentBag);
    setBoard(createEmptyBoard());
    setPlacedTiles([]);
    setCurrentPlayer(0);
    setGameStatus('playing');
    setConsecutiveSkips(0);
    setMoveHistory([]);
    setLastMoveInfo(null);
    setSelectedRackTile(null);
  }, []);

  // Select a tile from the rack
  const selectRackTile = useCallback((tile) => {
    setSelectedRackTile(prev => prev?.id === tile?.id ? null : tile);
  }, []);

  // Place selected tile on board cell
  const placeTileOnBoard = useCallback((row, col) => {
    const player = players[currentPlayer];
    if (!selectedRackTile) return { success: false, error: 'Selecteer eerst een letter.' };
    if (board[row][col] !== null) return { success: false, error: 'Dit vakje is al bezet.' };
    if (placedTiles.some(t => t.row === row && t.col === col))
      return { success: false, error: 'Dit vakje is al bezet.' };

    // Handle blank tile
    if (selectedRackTile.isBlank || selectedRackTile.letter === '*') {
      setBlankAssignment({ tileId: selectedRackTile.id, row, col });
      return { success: true, needsBlankLetter: true };
    }

    const newPlacedTile = { ...selectedRackTile, row, col };
    setPlacedTiles(prev => [...prev, newPlacedTile]);
    setPlayers(prev => prev.map((p, i) =>
      i === currentPlayer
        ? { ...p, rack: p.rack.filter(t => t.id !== selectedRackTile.id) }
        : p
    ));
    setSelectedRackTile(null);
    return { success: true };
  }, [selectedRackTile, board, placedTiles, players, currentPlayer]);

  // Assign letter to blank tile and place
  const assignBlankAndPlace = useCallback((letter) => {
    if (!blankAssignment) return;
    const { tileId, row, col } = blankAssignment;
    const player = players[currentPlayer];
    const tile = player.rack.find(t => t.id === tileId);
    if (!tile) return;

    const newPlacedTile = { ...tile, row, col, displayLetter: letter.toUpperCase(), points: 0 };
    setPlacedTiles(prev => [...prev, newPlacedTile]);
    setPlayers(prev => prev.map((p, i) =>
      i === currentPlayer
        ? { ...p, rack: p.rack.filter(t => t.id !== tileId) }
        : p
    ));
    setBlankAssignment(null);
    setSelectedRackTile(null);
  }, [blankAssignment, players, currentPlayer]);

  // Return a placed-but-not-confirmed tile back to rack
  const returnTileToRack = useCallback((tileId) => {
    const tile = placedTiles.find(t => t.id === tileId);
    if (!tile) return;
    setPlacedTiles(prev => prev.filter(t => t.id !== tileId));
    setPlayers(prev => prev.map((p, i) =>
      i === currentPlayer ? { ...p, rack: [...p.rack, { ...tile }] } : p
    ));
  }, [placedTiles, currentPlayer]);

  // Return ALL placed tiles to rack
  const returnAllTiles = useCallback(() => {
    const player = players[currentPlayer];
    const returnedTiles = placedTiles.map(t => ({ id: t.id, letter: t.letter, points: t.points, isBlank: t.isBlank }));
    setPlacedTiles([]);
    setPlayers(prev => prev.map((p, i) =>
      i === currentPlayer ? { ...p, rack: [...p.rack, ...returnedTiles] } : p
    ));
    setSelectedRackTile(null);
  }, [placedTiles, players, currentPlayer]);

  // Confirm move
  const confirmMove = useCallback(() => {
    const isFirst = moveHistory.length === 0;
    const placementResult = validatePlacement(placedTiles, board, isFirst);
    if (!placementResult.valid) {
      return { success: false, error: placementResult.error };
    }

    const wordResult = validateWords(placedTiles, board, dictionary);
    if (!wordResult.valid) {
      const invalid = wordResult.invalidWords.join(', ');
      return {
        success: false,
        error: `Ongeldig${wordResult.invalidWords.length > 1 ? 'e woorden' : ' woord'}: ${invalid}`
      };
    }

    const { total, wordBreakdown, bingo } = calculateMoveScore(placedTiles, board);

    // Place tiles on board
    const newBoard = board.map(row => [...row]);
    for (const t of placedTiles) {
      newBoard[t.row][t.col] = {
        letter: t.letter,
        displayLetter: t.displayLetter || t.letter,
        points: t.points,
        isBlank: t.isBlank,
        id: t.id,
      };
    }

    // Refill rack
    const { newRack, newBag } = fillRack(
      players[currentPlayer].rack,
      bag
    );

    const newPlayers = players.map((p, i) =>
      i === currentPlayer
        ? { ...p, score: p.score + total, rack: newRack }
        : p
    );

    const histEntry = {
      player: currentPlayer,
      words: wordBreakdown,
      score: total,
      bingo,
      turn: moveHistory.length + 1,
    };

    setBoard(newBoard);
    setBag(newBag);
    setPlayers(newPlayers);
    setPlacedTiles([]);
    setSelectedRackTile(null);
    setMoveHistory(prev => [...prev, histEntry]);
    setLastMoveInfo({ words: wordBreakdown, score: total, bingo, player: currentPlayer });
    setConsecutiveSkips(0);

    // Check end game
    const nextPlayer = 1 - currentPlayer;
    const nextPlayerHasTiles = newPlayers[nextPlayer].rack.length > 0;
    const currentHasTiles = newRack.length > 0;

    if (newBag.length === 0 && (!currentHasTiles || !nextPlayerHasTiles)) {
      endGame(newPlayers, newBag);
    } else {
      setCurrentPlayer(nextPlayer);
    }

    return { success: true, score: total, words: wordBreakdown, bingo };
  }, [placedTiles, board, dictionary, players, bag, currentPlayer, moveHistory]);

  // Skip turn
  const skipTurn = useCallback(() => {
    returnAllTiles();
    const newSkips = consecutiveSkips + 1;
    setConsecutiveSkips(newSkips);
    setLastMoveInfo({ skipped: true, player: currentPlayer });

    if (newSkips >= 4) { // both players skipped twice
      endGame(players, bag);
      return;
    }

    setCurrentPlayer(prev => 1 - prev);
    setMoveHistory(prev => [...prev, { player: currentPlayer, skip: true, turn: prev.length + 1 }]);
  }, [consecutiveSkips, players, bag, currentPlayer]);

  // Exchange tiles
  const exchangeTiles = useCallback((tileIds) => {
    if (tileIds.length === 0) return { success: false, error: 'Selecteer letters om te ruilen.' };
    if (bag.length < 7) return { success: false, error: 'Niet genoeg letters in de zak om te ruilen.' };

    const player = players[currentPlayer];
    const tilesToExchange = player.rack.filter(t => tileIds.includes(t.id));
    const remainingRack = player.rack.filter(t => !tileIds.includes(t.id));

    const newBag = shuffleBag([...bag, ...tilesToExchange]);
    const { newRack, newBag: finalBag } = fillRack(remainingRack, newBag);

    setPlayers(prev => prev.map((p, i) =>
      i === currentPlayer ? { ...p, rack: newRack } : p
    ));
    setBag(finalBag);
    setConsecutiveSkips(prev => prev + 1);
    setCurrentPlayer(prev => 1 - prev);
    setLastMoveInfo({ exchanged: tileIds.length, player: currentPlayer });
    setMoveHistory(prev => [...prev, { player: currentPlayer, exchange: true, turn: prev.length + 1 }]);

    return { success: true };
  }, [bag, players, currentPlayer]);

  const endGame = useCallback((finalPlayers, finalBag) => {
    // Subtract remaining tile values
    const updated = finalPlayers.map(p => {
      const penalty = p.rack.reduce((sum, t) => sum + t.points, 0);
      return { ...p, score: Math.max(0, p.score - penalty) };
    });
    setPlayers(updated);
    setGameStatus('ended');
  }, []);

  return {
    board, bag, players, currentPlayer, placedTiles,
    selectedRackTile, gameStatus, lastMoveInfo, moveHistory,
    blankAssignment, isFirstMove,
    startGame, selectRackTile, placeTileOnBoard, assignBlankAndPlace,
    returnTileToRack, returnAllTiles, confirmMove, skipTurn, exchangeTiles,
    setBlankAssignment,
  };
};
