// Wordfeud board premium square configuration (15x15)
// Types: TW=Triple Word, DW=Double Word, TL=Triple Letter, DL=Double Letter, ST=Start

export const BOARD_SIZE = 15;

export const PREMIUM_TYPES = {
  NORMAL: 'normal',
  DOUBLE_LETTER: 'dl',
  TRIPLE_LETTER: 'tl',
  DOUBLE_WORD: 'dw',
  TRIPLE_WORD: 'tw',
  START: 'start',
};

// Wordfeud uses a unique premium square layout (different from Scrabble)
const B = PREMIUM_TYPES.NORMAL;
const DL = PREMIUM_TYPES.DOUBLE_LETTER;
const TL = PREMIUM_TYPES.TRIPLE_LETTER;
const DW = PREMIUM_TYPES.DOUBLE_WORD;
const TW = PREMIUM_TYPES.TRIPLE_WORD;
const ST = PREMIUM_TYPES.START;

export const BOARD_LAYOUT = [
  [TW, B,  B,  DL, B,  B,  B,  TW, B,  B,  B,  DL, B,  B,  TW],
  [B,  DW, B,  B,  B,  TL, B,  B,  B,  TL, B,  B,  B,  DW, B ],
  [B,  B,  DW, B,  B,  B,  DL, B,  DL, B,  B,  B,  DW, B,  B ],
  [DL, B,  B,  DW, B,  B,  B,  DL, B,  B,  B,  DW, B,  B,  DL],
  [B,  B,  B,  B,  DW, B,  B,  B,  B,  B,  DW, B,  B,  B,  B ],
  [B,  TL, B,  B,  B,  TL, B,  B,  B,  TL, B,  B,  B,  TL, B ],
  [B,  B,  DL, B,  B,  B,  DL, B,  DL, B,  B,  B,  DL, B,  B ],
  [TW, B,  B,  DL, B,  B,  B,  ST, B,  B,  B,  DL, B,  B,  TW],
  [B,  B,  DL, B,  B,  B,  DL, B,  DL, B,  B,  B,  DL, B,  B ],
  [B,  TL, B,  B,  B,  TL, B,  B,  B,  TL, B,  B,  B,  TL, B ],
  [B,  B,  B,  B,  DW, B,  B,  B,  B,  B,  DW, B,  B,  B,  B ],
  [DL, B,  B,  DW, B,  B,  B,  DL, B,  B,  B,  DW, B,  B,  DL],
  [B,  B,  DW, B,  B,  B,  DL, B,  DL, B,  B,  B,  DW, B,  B ],
  [B,  DW, B,  B,  B,  TL, B,  B,  B,  TL, B,  B,  B,  DW, B ],
  [TW, B,  B,  DL, B,  B,  B,  TW, B,  B,  B,  DL, B,  B,  TW],
];

export const PREMIUM_COLORS = {
  [PREMIUM_TYPES.NORMAL]: '#c8b99a',
  [PREMIUM_TYPES.DOUBLE_LETTER]: '#5bb8d4',
  [PREMIUM_TYPES.TRIPLE_LETTER]: '#1a6fa8',
  [PREMIUM_TYPES.DOUBLE_WORD]: '#e8956d',
  [PREMIUM_TYPES.TRIPLE_WORD]: '#c23b22',
  [PREMIUM_TYPES.START]: '#e8956d',
};

export const PREMIUM_LABELS = {
  [PREMIUM_TYPES.DOUBLE_LETTER]: '2L',
  [PREMIUM_TYPES.TRIPLE_LETTER]: '3L',
  [PREMIUM_TYPES.DOUBLE_WORD]: '2W',
  [PREMIUM_TYPES.TRIPLE_WORD]: '3W',
  [PREMIUM_TYPES.START]: '★',
};

export const getPremiumType = (row, col) => BOARD_LAYOUT[row][col];
