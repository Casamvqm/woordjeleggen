import { BOARD_LAYOUT, PREMIUM_TYPES, BOARD_SIZE } from './boardConfig.js';
import { LETTER_VALUES } from './tileDistribution.js';

const { DOUBLE_LETTER, TRIPLE_LETTER, DOUBLE_WORD, TRIPLE_WORD, START } = PREMIUM_TYPES;

export const BINGO_BONUS = 50;
export const RACK_SIZE = 7;

/**
 * Extract all words formed by a move.
 * placedTiles: [{row, col, letter, points}]
 * boardCells: 2D array of placed tile objects or null
 * Returns array of {word, cells: [{row, col, letter, points, isNew}]}
 */
export const getFormedWords = (placedTiles, boardCells) => {
  if (placedTiles.length === 0) return [];

  const placedSet = new Set(placedTiles.map(t => `${t.row},${t.col}`));

  const getCell = (row, col) => {
    if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) return null;
    if (placedSet.has(`${row},${col}`)) {
      return placedTiles.find(t => t.row === row && t.col === col);
    }
    return boardCells[row][col];
  };

  const getWord = (startRow, startCol, dRow, dCol) => {
    // Find start of word
    let r = startRow, c = startCol;
    while (r - dRow >= 0 && c - dCol >= 0 && getCell(r - dRow, c - dCol)) {
      r -= dRow;
      c -= dCol;
    }
    // Collect cells
    const cells = [];
    while (r >= 0 && c >= 0 && r < BOARD_SIZE && c < BOARD_SIZE && getCell(r, c)) {
      const cell = getCell(r, c);
      cells.push({
        row: r, col: c,
        letter: cell.displayLetter || cell.letter,
        points: cell.points,
        isNew: placedSet.has(`${r},${c}`),
      });
      r += dRow;
      c += dCol;
    }
    return cells;
  };

  const words = [];
  const isHorizontal = placedTiles.length === 1 ||
    placedTiles.every(t => t.row === placedTiles[0].row);
  const isVertical = placedTiles.length === 1 ||
    placedTiles.every(t => t.col === placedTiles[0].col);

  if (isHorizontal && !isVertical) {
    // Main word is horizontal
    const mainCells = getWord(placedTiles[0].row, placedTiles[0].col, 0, 1);
    if (mainCells.length > 1) words.push({ word: mainCells.map(c => c.letter).join(''), cells: mainCells });
    // Check vertical words for each placed tile
    for (const t of placedTiles) {
      const vCells = getWord(t.row, t.col, 1, 0);
      if (vCells.length > 1) words.push({ word: vCells.map(c => c.letter).join(''), cells: vCells });
    }
  } else if (isVertical) {
    // Main word is vertical
    const mainCells = getWord(placedTiles[0].row, placedTiles[0].col, 1, 0);
    if (mainCells.length > 1) words.push({ word: mainCells.map(c => c.letter).join(''), cells: mainCells });
    // Check horizontal words for each placed tile
    for (const t of placedTiles) {
      const hCells = getWord(t.row, t.col, 0, 1);
      if (hCells.length > 1) words.push({ word: hCells.map(c => c.letter).join(''), cells: hCells });
    }
  }

  return words;
};

/**
 * Calculate score for a set of formed words.
 * placedSet: Set of "row,col" strings for newly placed tiles
 */
export const calculateWordScore = (wordCells, placedSet) => {
  let letterSum = 0;
  let wordMultiplier = 1;

  for (const { row, col, points, isNew } of wordCells) {
    if (isNew) {
      const premium = BOARD_LAYOUT[row][col];
      let letterMult = 1;
      if (premium === DOUBLE_LETTER) letterMult = 2;
      else if (premium === TRIPLE_LETTER) letterMult = 3;
      else if (premium === DOUBLE_WORD || premium === START) wordMultiplier *= 2;
      else if (premium === TRIPLE_WORD) wordMultiplier *= 3;
      letterSum += (points || 0) * letterMult;
    } else {
      letterSum += (points || 0);
    }
  }

  return letterSum * wordMultiplier;
};

/**
 * Calculate total score for a move.
 * Returns { total, wordBreakdown, bingo }
 */
export const calculateMoveScore = (placedTiles, boardCells) => {
  const words = getFormedWords(placedTiles, boardCells);
  const placedSet = new Set(placedTiles.map(t => `${t.row},${t.col}`));

  let total = 0;
  const wordBreakdown = [];

  for (const { word, cells } of words) {
    const score = calculateWordScore(cells, placedSet);
    total += score;
    wordBreakdown.push({ word, score });
  }

  const bingo = placedTiles.length === RACK_SIZE;
  if (bingo) total += BINGO_BONUS;

  return { total, wordBreakdown, bingo };
};
