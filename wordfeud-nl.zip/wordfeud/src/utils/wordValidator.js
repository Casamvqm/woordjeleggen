import { BOARD_SIZE, getPremiumType, PREMIUM_TYPES } from './boardConfig.js';
import { getFormedWords } from './scoring.js';

/**
 * Validate tile placement before confirming the move.
 * Returns { valid: bool, error: string | null }
 */
export const validatePlacement = (placedTiles, boardCells, isFirstMove) => {
  if (placedTiles.length === 0) {
    return { valid: false, error: 'Plaats minimaal één letter.' };
  }

  // All tiles must be in same row or same column
  const rows = [...new Set(placedTiles.map(t => t.row))];
  const cols = [...new Set(placedTiles.map(t => t.col))];
  const isHorizontal = rows.length === 1;
  const isVertical = cols.length === 1;

  if (!isHorizontal && !isVertical) {
    return { valid: false, error: 'Letters moeten op één rij of kolom liggen.' };
  }

  // Check no gaps in the placed word (including existing tiles on board)
  if (isHorizontal && placedTiles.length > 1) {
    const row = rows[0];
    const minCol = Math.min(...cols);
    const maxCol = Math.max(...cols);
    for (let c = minCol; c <= maxCol; c++) {
      const hasPlaced = placedTiles.some(t => t.col === c);
      const hasBoard = boardCells[row][c] !== null;
      if (!hasPlaced && !hasBoard) {
        return { valid: false, error: 'Er mag geen gat zitten tussen de letters.' };
      }
    }
  }

  if (isVertical && placedTiles.length > 1) {
    const col = cols[0];
    const minRow = Math.min(...rows);
    const maxRow = Math.max(...rows);
    for (let r = minRow; r <= maxRow; r++) {
      const hasPlaced = placedTiles.some(t => t.row === r);
      const hasBoard = boardCells[r][col] !== null;
      if (!hasPlaced && !hasBoard) {
        return { valid: false, error: 'Er mag geen gat zitten tussen de letters.' };
      }
    }
  }

  // First move must cover center (7,7)
  const centerRow = 7, centerCol = 7;
  if (isFirstMove) {
    const coversCenter = placedTiles.some(t => t.row === centerRow && t.col === centerCol);
    if (!coversCenter) {
      return { valid: false, error: 'Het eerste woord moet het middelste vakje bedekken.' };
    }
    if (placedTiles.length < 2) {
      return { valid: false, error: 'Het eerste woord moet minimaal twee letters hebben.' };
    }
  } else {
    // Must connect to existing tiles
    const connects = placedTiles.some(t => isAdjacentToExisting(t.row, t.col, boardCells, placedTiles));
    if (!connects) {
      return { valid: false, error: 'Letters moeten aansluiten op bestaande letters.' };
    }
  }

  return { valid: true, error: null };
};

const isAdjacentToExisting = (row, col, boardCells, placedTiles) => {
  const dirs = [[-1,0],[1,0],[0,-1],[0,1]];
  const placedSet = new Set(placedTiles.map(t => `${t.row},${t.col}`));
  for (const [dr, dc] of dirs) {
    const r = row + dr, c = col + dc;
    if (r >= 0 && r < BOARD_SIZE && c >= 0 && c < BOARD_SIZE) {
      if (boardCells[r][c] !== null && !placedSet.has(`${r},${c}`)) return true;
    }
  }
  return false;
};

/**
 * Validate all words formed by a move against the dictionary.
 * Returns { valid: bool, invalidWords: string[] }
 */
export const validateWords = (placedTiles, boardCells, dictionary) => {
  const words = getFormedWords(placedTiles, boardCells);

  if (words.length === 0) {
    return { valid: false, invalidWords: [], error: 'Geen geldig woord gevormd.' };
  }

  const invalidWords = [];
  for (const { word } of words) {
    const lower = word.toLowerCase();
    if (!dictionary.has(lower)) {
      invalidWords.push(word);
    }
  }

  return { valid: invalidWords.length === 0, invalidWords };
};

/**
 * Get all valid positions where next tile can be placed given current placed tiles.
 */
export const getValidPositions = (placedTiles, boardCells, isFirstMove) => {
  const valid = new Set();
  const occupied = new Set([
    ...placedTiles.map(t => `${t.row},${t.col}`),
    ...boardCells.flatMap((row, r) =>
      row.map((cell, c) => cell ? `${r},${c}` : null).filter(Boolean)
    )
  ]);

  if (placedTiles.length === 0) {
    if (isFirstMove) {
      // Any position that includes or leads toward center
      for (let r = 0; r < BOARD_SIZE; r++)
        for (let c = 0; c < BOARD_SIZE; c++)
          if (!occupied.has(`${r},${c}`)) valid.add(`${r},${c}`);
    } else {
      // Adjacent to existing board tiles
      for (let r = 0; r < BOARD_SIZE; r++) {
        for (let c = 0; c < BOARD_SIZE; c++) {
          if (!boardCells[r][c]) continue;
          const dirs = [[-1,0],[1,0],[0,-1],[0,1]];
          for (const [dr, dc] of dirs) {
            const nr = r+dr, nc = c+dc;
            if (nr >= 0 && nr < BOARD_SIZE && nc >= 0 && nc < BOARD_SIZE && !occupied.has(`${nr},${nc}`)) {
              valid.add(`${nr},${nc}`);
            }
          }
        }
      }
    }
    return valid;
  }

  // Already have placed tiles — constrain to same row/col
  const rows = [...new Set(placedTiles.map(t => t.row))];
  const cols = [...new Set(placedTiles.map(t => t.col))];

  if (rows.length === 1) {
    // Horizontal — extend or fill same row
    const row = rows[0];
    for (let c = 0; c < BOARD_SIZE; c++) {
      if (!occupied.has(`${row},${c}`)) valid.add(`${row},${c}`);
    }
  } else if (cols.length === 1) {
    // Vertical — extend or fill same col
    const col = cols[0];
    for (let r = 0; r < BOARD_SIZE; r++) {
      if (!occupied.has(`${r},${col}`)) valid.add(`${r},${col}`);
    }
  }

  return valid;
};
