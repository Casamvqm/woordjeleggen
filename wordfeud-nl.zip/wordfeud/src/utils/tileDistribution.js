// Dutch Wordfeud/Scrabble tile distribution and point values

export const DUTCH_TILES = [
  // [letter, points, count]
  ['A', 1, 6],
  ['B', 3, 2],
  ['C', 5, 2],
  ['D', 2, 5],
  ['E', 1, 18],
  ['F', 4, 2],
  ['G', 3, 3],
  ['H', 4, 2],
  ['I', 1, 4],
  ['J', 4, 2],
  ['K', 3, 3],
  ['L', 3, 3],
  ['M', 3, 3],
  ['N', 1, 10],
  ['O', 1, 6],
  ['P', 3, 2],
  ['Q', 10, 1],
  ['R', 2, 5],
  ['S', 2, 5],
  ['T', 2, 5],
  ['U', 4, 3],
  ['V', 4, 2],
  ['W', 5, 2],
  ['X', 8, 1],
  ['Y', 8, 1],
  ['Z', 4, 2],
  ['*', 0, 2], // blanks/jokers
];

export const LETTER_VALUES = Object.fromEntries(
  DUTCH_TILES.map(([letter, points]) => [letter, points])
);

export const createBag = () => {
  const bag = [];
  let id = 0;
  for (const [letter, points, count] of DUTCH_TILES) {
    for (let i = 0; i < count; i++) {
      bag.push({ id: `tile-${id++}`, letter, points, isBlank: letter === '*' });
    }
  }
  return shuffleBag(bag);
};

export const shuffleBag = (bag) => {
  const arr = [...bag];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
};

export const TILE_COUNT = DUTCH_TILES.reduce((sum, [, , count]) => sum + count, 0);
